#include "visualizer.h"

visualizer::visualizer(QWidget *parent):QWidget(parent){

    vboxAUX = new QVBoxLayout();
    vboxDemo = new QVBoxLayout();
    hbox = new QHBoxLayout();
    aux = new QCheckBox("AUX");
    demo = new QCheckBox("Demo");

    amplitude = new QSlider();  //if wanted horizontal "Qt::Horizontal"
    amplitude->setSliderPosition(50);

    setWindowTitle("Audio Visualizer");
    //setStyleSheet("background-color:#303030;");     //background color
    //resize(420, 240);

    hbox->addLayout(vboxAUX);
    hbox->addLayout(vboxDemo);

    vboxAUX->addWidget(aux);
    vboxAUX->addWidget(amplitude);
    vboxDemo->addWidget(demo);

    this->setLayout(hbox);

    serConnect();

    setContextMenuPolicy(Qt::CustomContextMenu);    //Context Menu
    connect(this, SIGNAL(customContextMenuRequested(const QPoint &)),
            this, SLOT(ShowContextMenu(const QPoint &)));

    setWindowFlags(Qt::FramelessWindowHint);
}

visualizer::~visualizer(){
}

/////////////////////////////////SERIAL PORT////////////////////////////////////////
void visualizer::serConnect(void){
        serial->setPort(qt.COM12);
            if(serial->isOpen())//if port is already open...
                QMessageBox::warning(this,"Oops!","Serial port is already open. Please disconnect first");
            else{ //if port is available and not open...open it
                if (serial->open(QIODevice::ReadWrite) == false){
                    QMessageBox::warning(this,"Oops!","Failed to open port");
                    serial->close(); //if opening port failed close it
                }
                else { //if port opened successfully....set its parameters
                    serial->setBaudRate(QSerialPort::Baud9600);//BaudRate //,QSerialPort::AllDirections);
                    serial->setDataBits(QSerialPort::Data8);// 8-bit data
                    serial->setParity(QSerialPort::NoParity); // no parity
                    serial->setFlowControl(QSerialPort::NoFlowControl); //no flow control
                    serial->setStopBits(QSerialPort::OneStop);// 1 stop bit;
               }
           }
}

////////////////////////////////CONTEXT MENU///////////////////////////////////////
void visualizer::ShowContextMenu(const QPoint &pos)
{
   QMenu contextMenu(tr("Context menu"), this);
   contextMenu.setStyleSheet("background-color:pink");
   QAction action1("Quit", this);
   connect(&action1, SIGNAL(triggered()), this, SLOT(close()));
   contextMenu.addAction(&action1);
   contextMenu.exec(mapToGlobal(pos));
}

//////////////////////////////////DRAGGABLE///////////////////////////////////////
void visualizer::mousePressEvent(QMouseEvent *event) {
    m_nMouseClick_X_Coordinate = event->x();
    m_nMouseClick_Y_Coordinate = event->y();
}

void visualizer::mouseMoveEvent(QMouseEvent *event) {
    move(event->globalX()-m_nMouseClick_X_Coordinate,event->globalY()-m_nMouseClick_Y_Coordinate);
}
