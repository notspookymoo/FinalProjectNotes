#ifndef VISUALIZER_H
#define VISUALIZER_H

#include <QWidget>
#include <QCheckBox>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPushButton>
#include <QMenu>
#include <QAction>
#include <QMouseEvent>
#include <QSlider>
#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>
#include <QMessageBox>

class visualizer : public QWidget
{
    Q_OBJECT
protected:
    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
public:
    visualizer(QWidget *parent = 0);
    ~visualizer();
public slots:
    void ShowContextMenu(const QPoint &pos);      //Context menu
    void serConnect(void);
private:
    QVBoxLayout *vboxAUX, *vboxDemo;
    QHBoxLayout *hbox;
    QCheckBox *aux, *demo;
    QSlider *amplitude;
    int m_nMouseClick_X_Coordinate;
    int m_nMouseClick_Y_Coordinate;
};

#endif // VISUALIZER_H
