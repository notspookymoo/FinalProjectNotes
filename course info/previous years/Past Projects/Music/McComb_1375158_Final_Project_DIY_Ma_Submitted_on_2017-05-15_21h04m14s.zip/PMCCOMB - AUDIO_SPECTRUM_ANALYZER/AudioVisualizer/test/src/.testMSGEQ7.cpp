#include "mbed.h"
#include "MSGEQ7.h"
#define MAX 100

MSGEQ7 eq(D11, A3, A0); //reset, strobe, analog

int main() {
    while(1) {
        eq.readInt(MAX); //Read in integer frequency data with max value set to 'MAX'

        for(int i = 0; i < 7; i++){
          if (eq.freqDataInt[i]<30)
            eq.freqDataInt[i]=0;
        }

        //Print out frequency data
        for(int i = 0; i < 7; i++){
          printf("%d\n", eq.freqDataInt[i]);
        }
        printf("---------------------------\n");
        wait(1.0);
    }
}
