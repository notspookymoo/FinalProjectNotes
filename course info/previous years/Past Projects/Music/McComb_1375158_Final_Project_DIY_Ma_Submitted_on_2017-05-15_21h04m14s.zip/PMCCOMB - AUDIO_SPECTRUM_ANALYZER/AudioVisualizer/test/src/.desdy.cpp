#include "mbed.h"

DigitalOut reset(A2);
DigitalOut strobe(A1);
AnalogIn ain(A5);
float freq[7];
int main() {
    strobe = 1;
    while(1) {
      reset = 1;
      wait_us(1);
      reset = 0;
      wait_us(75);
      for(int i = 0 ; i < 7 ; i++){
        strobe=0;wait_us(40);
        freq[i] = ain.read(); wait_us(20);
        strobe=1;wait_us(40);
      }

      for(int i = 0; i < 7 ; i++){
        printf("%5.3f ",freq[i]);
        //freq[i]=0.0;
      }
      printf("\n");
      wait(1.0);
    }
}
