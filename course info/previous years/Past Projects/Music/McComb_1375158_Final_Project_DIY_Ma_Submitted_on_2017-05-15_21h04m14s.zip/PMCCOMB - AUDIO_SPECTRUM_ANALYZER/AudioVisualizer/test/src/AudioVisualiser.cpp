#include "mbed.h"
#include "MSGEQ7.h"   //Library for MSGEQ7 (found online)
#include <time.h>
#include <stdlib.h>

#define MAX 100
#define START 0x80
#define STOP  0x81
//Serial pc()

void demo(PwmOut *a[7]);
void audioInput(PwmOut *a[7]);
MSGEQ7 eq(D11, A3, A0); //reset, strobe, analog

int main() {
  /* bool messageReady = false; // initially there's no RPC command
   char i=0;
   char next_val = 0;
   char val =0;
   while(1){
       // If there's no command available in buffer let's look for one on the
       //serial port
       if(messageReady == false){
           next_val = pc.getc();
           //if we receive START....this is beginning of command
           if(next_val == START){
               i=0;
               valbuffer[i++] = next_val;
               do{ //keep reading the rpc command bytes until we get to stop
                   next_val = pc.getc();
                   valbuffer[i++] = next_val;
               }while(next_val != STOP);//we now have an RPC command
               messageReady = true;
           }
       }

       if(messageReady == true){ //let's interpret this command
                   switch(valbuffer[1]){
                       case SETRGB:
                           setRGB(valbuffer[2],valbuffer[3],valbuffer[4]);
                           pc.putc(SETRGB);
                           pc.putc(STOP);
                           break;
                       case READPUSHBUTTON:
                           val = readPushbutton();
                           pc.putc(READPUSHBUTTON);
                           pc.putc(val);
                           pc.putc(STOP);
                           break;
                       default:
                           pc.putc(0x00);
                           break;
                   }
                   messageReady = false;
                   wait(0.2);
                   while(pc.readable()){pc.getc();}//flush serial buffer
                   // RPC command interpreted...wait for next command

       }*/
  PinName pins[7] = {A1,D15,D14,D12,D10,D9,D8};
  PwmOut *fan[7];
  for(int i = 0; i<7; i++){
    fan[i] = new PwmOut(pins[i]);
    fan[i]->period(0.001);
  }

  while(1){
    //demo(fan);
    audioInput(fan);
  }
}

///////////////////////////////DEMO CODE/////////////////////////////////
void demo(PwmOut *a[7]){

  for(int i=0;i<7;i++){     //1.Tests all fans functionnality 1 by 1.
    a[i]->write(0.99);
    wait(1.5);
    a[i]->write(0.0);
  }

  for(int i=0;i<100;i++){    //2.Tests all fans functionnality at the same time.
    for(int j=0;j<7;j++){
      a[j]->write(i/100.0);
    }
    wait(0.02);
  }
  wait(1);
  for(int i=100;i>0;i--){
    for(int j=0;j<7;j++){
      a[j]->write(i/100.0);
    }
    wait(0.02);
  }
  wait(1);

  for(int i=0;i<7;i++){     //3.Tests random fans (7 times)
    srand (time(NULL));
    int randFan = rand() % 7;

    a[randFan]->write(0.99);
    wait(1.5);
    a[randFan]->write(0.0);
  }
}

//////////////////////////////MSGEQ7 CODE////////////////////////////////
void audioInput(PwmOut *a[7]){
  {
    eq.readInt(MAX); //Read in integer frequency data with max value set to 'MAX'

    for(int i = 0; i < 7; i++){   //stores data taken from MSGEQ7
      if (eq.freqDataInt[i]<10){
        eq.freqDataInt[i]=0;
      }
    }

    for(int i = 0; i < 7; i++){    //Prints out frequency data collected
      printf("%d\n", eq.freqDataInt[i]);
    }
    printf("---------------------------\n");
  //  wait(1.0);  //to be removed once complete

    for(int i = 0; i < 7; i++){   //writes MSGEQ7 data to fans
      a[i]->write(eq.freqDataInt[i]/80);
    }
  }
}
