"desdy.cpp"
"testFans1by1.cpp"
"testMSGEQ7"
Are all sample code created and used purely for testing components.

"AudioVisualiser.cpp" is the only code that matters