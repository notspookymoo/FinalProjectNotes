#include "mbed.h"

PwmOut fan1(A1);
PwmOut fan2(D15);
PwmOut fan3(D14);
PwmOut fan4(D12);
PwmOut fan5(D10);
PwmOut fan6(D9);
PwmOut fan7(D8);

int main() {
  fan1.period(0.001);
  fan2.period(0.001);
  fan3.period(0.001);
  fan4.period(0.001);
  fan5.period(0.001);
  fan6.period(0.001);
  fan7.period(0.001);

  while(1){
  fan1.write(0.9);
  wait_ms(1000);
  fan1.write(0.0);

  fan2.write(0.9);
  wait_ms(1000);
  fan2.write(0.0);

  fan3.write(0.9);
  wait_ms(1000);
  fan3.write(0.0);

  fan4.write(0.9);
  wait_ms(1000);
  fan4.write(0.0);

  fan5.write(0.9);
  wait_ms(1000);
  fan5.write(0.0);

  fan6.write(0.9);
  wait_ms(1000);
  fan6.write(0.0);

  fan7.write(0.9);
  wait_ms(1000);
  fan7.write(0.0);
  }

}
