#include "mbed.h"
#include "string"

Serial blue(PA_9,PA_10);
Serial pc(PA_2,PA_3);
Ticker timer;
string red;
bool run;
PwmOut rightWheelSpeed(A3);//A1
PwmOut leftWheelSpeed(A1);//A3
PwmOut BladeStates(D13);
DigitalOut BladeSpin1(D11);
DigitalOut BladeSpin2(D12);
DigitalOut INArightWheel(PC_3);
DigitalOut INBrightWheel(PC_2);
DigitalOut INAleftWheel(A0);
DigitalOut INBleftWheel(A2);
DigitalOut led(LED2);

void fwd(void);
void bwd(void);
void stop_alm(void);
void turnright(void);
void turnleft(void);
void BladeOn(void);
void BladeOff(void);
void power_off(void);

int main(void)
{
    rightWheelSpeed.period(0.0005);
    leftWheelSpeed.period(0.0005);
    rightWheelSpeed.write(0.8);
    leftWheelSpeed.write(0.8);
    pc.baud(9600);
    blue.baud(9600);
    blue.printf("Connection Established");
    while(1) {
        while(blue.readable()) {
            red = blue.putc(blue.getc());
            if(red == "0") {
                led.write(0);
                power_off();
                //stop
                run = false;
            }
            if(red == "1") {
                //start
                run = true;
            }
            if(red == "2" && run == true) {
                led.write(1);
                fwd();
            }
            if(red == "3" && run == true) {
                led.write(1);
                bwd();
            }
            if(red == "4" && run == true) {
                led.write(1);
                turnleft();
            }
            
            if(red == "5" && run == true) {
                led.write(1);
                turnright();
            }
            if(red == "6") {
                led.write(0);
                stop_alm();
            }
            if(red == "7" && run == true) {
                led.write(0);
                BladeOff();
            }
            if(red == "8" && run == true) {
                led.write(1);
                BladeOn();
            }  
        }
    }
}

void fwd(void)
{
    INArightWheel.write(1);
    INBrightWheel.write(0);
    INAleftWheel.write(1);
    INBleftWheel.write(0);
}

void bwd(void)
{
    INArightWheel.write(0);
    INBrightWheel.write(1);
    INAleftWheel.write(0);
    INBleftWheel.write(1);
}

void stop_alm(void)
{
    INArightWheel.write(0);
    INBrightWheel.write(0);
    INAleftWheel.write(0);
    INBleftWheel.write(0);
}
void turnright(void)
{
    INArightWheel.write(0);
    INBrightWheel.write(1);
    INAleftWheel.write(1);
    INBleftWheel.write(0);
}
void turnleft(void)
{
    INArightWheel.write(1);
    INBrightWheel.write(0);
    INAleftWheel.write(0);
    INBleftWheel.write(1);
}
void BladeOn(void)
{
    BladeSpin1.write(1);
    BladeSpin2.write(1);
}
void BladeOff(void)
{
    BladeSpin1.write(0);
    BladeSpin2.write(0);
}
void power_off(void)
{
stop_alm();
BladeOff();
    
}